package com.example.usergithub.ui.detailUser

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.annotation.StringRes
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.usergithub.R
import com.example.usergithub.databinding.ActivityDetailUserBinding
import com.example.usergithub.ui.follow.SectionPagerAdapter
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class DetailUserActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailUserBinding
    private lateinit var detailViewModel: DetailUserViewModel
    private var  username : String? = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        val avatarUrl = intent.getStringExtra("avatarUrl").toString()
        username = intent.getStringExtra("username")
        val stringUsername = username.toString()
        binding.username.text = stringUsername

        detailViewModel = ViewModelProvider(this)[DetailUserViewModel::class.java]
        setupProfile(stringUsername, avatarUrl)

        detailViewModel.isLoading.observe(this) {
            showLoading(it)
        }

        setViewPager()

    }

    private fun setupProfile(username: String, avatarUrl: String) {
        Glide.with(this)
            .load(avatarUrl)
            .apply(RequestOptions.circleCropTransform())
            .into(binding.imgAvatar)
        binding.username.text = username
        detailViewModel.getDetailUser(username)
        detailViewModel.detailUser.observe(this) { userDetail ->
            val followers = userDetail?.followers.toString()
            val following = userDetail?.following.toString()
            val followersText = "$followers Follower"
            val followingText = "$following Following"
            binding.tvFollowers.text = followersText
            binding.tvFollowing.text = followingText
            val realName = userDetail?.name
            binding.tvName.text = realName


        }

    }

    private fun setViewPager() {
        val adapter = SectionPagerAdapter(this)
        adapter.username = username!!
        val viewPager : ViewPager2 = binding.viewPager
        viewPager.adapter = adapter
        val tabs: TabLayout = binding.tabs
        TabLayoutMediator(tabs, viewPager) { tab, position ->
            val tabText = this.getString(TAB_TITLES[position])
            tab.text = tabText
        }.attach()

        supportActionBar?.elevation = 0f
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    companion object {
        @StringRes
        private val TAB_TITLES = arrayOf(
            R.string.tab_text_1,
            R.string.tab_text_2
        )
    }
}