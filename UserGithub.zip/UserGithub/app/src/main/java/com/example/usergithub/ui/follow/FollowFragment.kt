package com.example.usergithub.ui.follow

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.usergithub.databinding.FragmentFollowBinding
import com.example.usergithub.ui.UserGithubAdapter


class FollowFragment : Fragment() {
    private lateinit var binding: FragmentFollowBinding
    private lateinit var adapter: UserGithubAdapter
    private var position : Int = 0
    var username : String? = ""

    companion object {
        const val ARG_POSITION = "section_number"
        const val ARG_USERNAME = "username"
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentFollowBinding.inflate(layoutInflater)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        arguments?.let {
            position = it.getInt(ARG_POSITION)
            username = it.getString(ARG_USERNAME)
        }
        binding.rvFollowList.setHasFixedSize(true)
        val layoutManager = LinearLayoutManager(requireActivity())
        binding.rvFollowList.layoutManager = layoutManager


        adapter = UserGithubAdapter()
        binding.rvFollowList.adapter = adapter

        if (isAdded && !isDetached) {
            val viewModel = ViewModelProvider(this)[FollowViewModel::class.java]

            viewModel.isLoading.observe(viewLifecycleOwner) {
                showLoading(it)
            }

            viewModel.followList.observe(viewLifecycleOwner) { followList ->
                if (followList != null && followList.isNotEmpty()) {
                    adapter.submitList(followList)
                } else {
                    val message = if (position == 1) {
                        "$username tidak memiliki follower"
                    } else {
                        "$username tidak memiliki following"
                    }
                    Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
                }
            }

            viewModel.getFollowList(username!!, position)

        }
    }
    private fun showLoading(isLoading: Boolean) {
        binding.rvFollowList.visibility = if (isLoading) View.GONE else View.VISIBLE
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }


}