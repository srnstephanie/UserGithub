package com.example.usergithub.ui.main

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.usergithub.data.response.ItemsItem
import com.example.usergithub.databinding.ActivityMainBinding
import com.example.usergithub.ui.UserGithubAdapter

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this)[MainViewModel::class.java]

        supportActionBar?.title = "User Github"


        val layoutManager = LinearLayoutManager(this)
        binding.listUser.layoutManager = layoutManager

        val itemDecoration = DividerItemDecoration(this, layoutManager.orientation)
        binding.listUser.addItemDecoration(itemDecoration)

        viewModel.user.observe(this){
            items -> setUserData(items)
        }
        viewModel.isLoading.observe(this){
            showLoading(it)
        }
        viewModel.isSearch.observe(this){
            showToast(it)
        }
        with(binding) {
            searchView.setupWithSearchBar(searchBar)
            searchView
                .editText
                .setOnEditorActionListener { _, actionId, _ ->
                    if(actionId == EditorInfo.IME_ACTION_SEARCH){
                        performSearch(searchView.text.toString())
                        searchBar.text = searchView.text
                        searchView.hide()
                        return@setOnEditorActionListener true
                    }
                    false
                }
        }
    }

    private fun setUserData(user: List<ItemsItem>){
        val adapter = UserGithubAdapter()
        adapter.submitList(user)
        binding.listUser.adapter = adapter
    }

    private fun showLoading(isLoading: Boolean) {
        binding.listUser.visibility = if (isLoading) View.GONE else View.VISIBLE
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }
    private fun performSearch(query: String) {
        viewModel.searchUser(query)
    }
    private fun showToast(isSearch : Boolean){
        if (isSearch ) {
            val message = "Pencarian selesai"
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        }
    }
}